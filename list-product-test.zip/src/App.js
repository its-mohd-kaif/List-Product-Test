import LandingPage from "./Components/LandingPage";

function App() {
  return (
    <div>
      <LandingPage />
    </div>
  );
}

export default App;
